#!/usr/bin/env python3
"""
generate_pptx.py
Generates the official 15-slide PowerPoint presentation for the
CPU and Memory Stress Testing Tool (OSSP Hackathon Edition).
Complies with Section 12 specifications:
- Professional engineering style: Dark Navy (#0A192F) background
- Restrained electric-blue accents (#00B4D8 / #64DFDF)
- Clean typography and structured technical cards/tables
- Editable PowerPoint file
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE

# --- Color Palette ---
COLOR_BG_DARK = RGBColor(10, 25, 47)       # #0A192F - Main Dark Navy Background
COLOR_CARD_BG = RGBColor(17, 34, 64)       # #112240 - Container Card Background
COLOR_CARD_BORDER = RGBColor(35, 53, 84)   # #233554 - Subtle Container Border
COLOR_ACCENT_BLUE = RGBColor(0, 180, 216)  # #00B4D8 - Vibrant Electric Blue
COLOR_ACCENT_CYAN = RGBColor(100, 223, 223)# #64DFDF - Bright Cyan / Highlight
COLOR_TEXT_WHITE = RGBColor(255, 255, 255) # Pure White Headings
COLOR_TEXT_LIGHT = RGBColor(204, 214, 246) # #CCD6F6 - Soft Light Silver Body
COLOR_TEXT_MUTED = RGBColor(136, 146, 176) # #8892B0 - Slate Gray Captions
COLOR_GREEN_PASS = RGBColor(46, 196, 182)  # #2EC4B6 - Success Emerald
COLOR_RED_ALERT = RGBColor(231, 29, 54)    # #E71D36 - Warning / Race Hazard

def create_presentation():
    prs = Presentation()
    # 16:9 Widescreen layout
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]

    def set_slide_background(slide):
        bg_shape = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height
        )
        bg_shape.fill.solid()
        bg_shape.fill.fore_color.rgb = COLOR_BG_DARK
        bg_shape.line.fill.background()
        return bg_shape

    def add_header(slide, title_text, category_text="OPERATING SYSTEMS & SYSTEM PROGRAMMING HACKATHON"):
        # Category Tag
        cat_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.7), Inches(0.4))
        tf_cat = cat_box.text_frame
        tf_cat.word_wrap = True
        p_cat = tf_cat.paragraphs[0]
        p_cat.text = category_text.upper()
        p_cat.font.name = 'Segoe UI'
        p_cat.font.size = Pt(11)
        p_cat.font.bold = True
        p_cat.font.color.rgb = COLOR_ACCENT_CYAN

        # Title
        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.7), Inches(11.7), Inches(0.8))
        tf_title = title_box.text_frame
        tf_title.word_wrap = True
        p_title = tf_title.paragraphs[0]
        p_title.text = title_text
        p_title.font.name = 'Segoe UI'
        p_title.font.size = Pt(24)
        p_title.font.bold = True
        p_title.font.color.rgb = COLOR_TEXT_WHITE

        # Divider line
        line = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.5), Inches(11.7), Inches(0.02)
        )
        line.fill.solid()
        line.fill.fore_color.rgb = COLOR_ACCENT_BLUE
        line.line.fill.background()

    def add_card(slide, left, top, width, height, title, body_lines, border_color=COLOR_CARD_BORDER):
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        card.fill.solid()
        card.fill.fore_color.rgb = COLOR_CARD_BG
        card.line.color.rgb = border_color
        card.line.width = Pt(1.5)

        tb = slide.shapes.add_textbox(left + Inches(0.2), top + Inches(0.2), width - Inches(0.4), height - Inches(0.4))
        tf = tb.text_frame
        tf.word_wrap = True

        p0 = tf.paragraphs[0]
        p0.text = title
        p0.font.name = 'Segoe UI'
        p0.font.size = Pt(16)
        p0.font.bold = True
        p0.font.color.rgb = COLOR_ACCENT_CYAN
        p0.space_after = Pt(10)

        for line in body_lines:
            p = tf.add_paragraph()
            p.text = line
            p.font.name = 'Segoe UI'
            p.font.size = Pt(12)
            p.font.color.rgb = COLOR_TEXT_LIGHT
            p.space_after = Pt(6)

        return card

    # =========================================================================
    # SLIDE 1: Title Slide
    # =========================================================================
    s1 = prs.slides.add_slide(blank_layout)
    set_slide_background(s1)

    # Accent decorative box
    dec = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.8), Inches(0.15), Inches(3.2))
    dec.fill.solid()
    dec.fill.fore_color.rgb = COLOR_ACCENT_CYAN
    dec.line.fill.background()

    tb = s1.shapes.add_textbox(Inches(1.2), Inches(1.8), Inches(11.0), Inches(3.2))
    tf = tb.text_frame
    tf.word_wrap = True

    p = tf.paragraphs[0]
    p.text = "CPU and Memory Stress Testing Tool"
    p.font.name = 'Segoe UI'
    p.font.size = Pt(36)
    p.font.bold = True
    p.font.color.rgb = COLOR_TEXT_WHITE
    p.space_after = Pt(10)

    p2 = tf.add_paragraph()
    p2.text = "High-Performance Workload Generator & OS Kernel Behavioral Analysis Utility"
    p2.font.name = 'Segoe UI'
    p2.font.size = Pt(18)
    p2.font.bold = True
    p2.font.color.rgb = COLOR_ACCENT_BLUE
    p2.space_after = Pt(18)

    p3 = tf.add_paragraph()
    p3.text = "OSSP Hackathon Edition  |  Comprehensive Implementation of Course Outcomes CO1 – CO6"
    p3.font.name = 'Segoe UI'
    p3.font.size = Pt(13)
    p3.font.color.rgb = COLOR_TEXT_MUTED
    p3.space_after = Pt(24)

    # Team details card
    team_card = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(5.3), Inches(11.7), Inches(1.4))
    team_card.fill.solid()
    team_card.fill.fore_color.rgb = COLOR_CARD_BG
    team_card.line.color.rgb = COLOR_ACCENT_BLUE
    team_card.line.width = Pt(1)

    team_tb = s1.shapes.add_textbox(Inches(1.0), Inches(5.4), Inches(11.3), Inches(1.2))
    tt_f = team_tb.text_frame
    p_t = tt_f.paragraphs[0]
    p_t.text = "TEAM PARTICIPATION & MODULE RESPONSIBILITIES:"
    p_t.font.name = 'Segoe UI'
    p_t.font.size = Pt(12)
    p_t.font.bold = True
    p_t.font.color.rgb = COLOR_ACCENT_CYAN
    p_t.space_after = Pt(4)

    p_t2 = tt_f.add_paragraph()
    p_t2.text = "• Process Management & CPU Stress (CO2)   • Virtual Memory & Demand Paging (CO4)   • IPC & Signals (CO3)\n• Threading & Synchronization (CO6)   • Low-Level File I/O & Reports (CO5)   • CLI & Safety Controls (CO1)"
    p_t2.font.name = 'Segoe UI'
    p_t2.font.size = Pt(11)
    p_t2.font.color.rgb = COLOR_TEXT_LIGHT

    # =========================================================================
    # SLIDE 2: Problem Statement & Motivation
    # =========================================================================
    s2 = prs.slides.add_slide(blank_layout)
    set_slide_background(s2)
    add_header(s2, "Problem Statement & Systems Engineering Motivation")

    add_card(s2, Inches(0.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "The Performance Engineering Challenge", [
                 "• Unpredictable Workload Spikes: High-throughput servers face sudden surges in CPU computations and memory consumption, stressing the OS scheduler and memory subsystem.",
                 "• Complex Kernel Interactions: When utilization escalates, processes experience context switching overhead, TLB shootdowns, and hardware page fault exceptions.",
                 "• Opaque Existing Tools: Standard benchmark utilities act as black boxes, obscuring system call traces, IPC synchronization latencies, and kernel paging behaviors.",
                 "• Academic Need: A cohesive systems tool is required to demonstrate how foundational OS concepts operate together under real hardware stress."
             ])

    add_card(s2, Inches(6.8), Inches(1.8), Inches(5.7), Inches(5.0),
             "Key Objectives of This Solution", [
                 "• Direct Kernel Observability: Surface true system metrics via direct parsing of /proc/stat, /proc/meminfo, and /proc/self/status.",
                 "• Safe & Repeatable Stress: Implement strict safety boundaries preventing OS starvation or OOM (Out Of Memory) killer crashes.",
                 "• Full OSSP Curriculum Coverage: Cover all six Course Outcomes (CO1 to CO6) in an integrated, demonstrable systems program.",
                 "• Empirical Verification: Validate performance scaling, memory access overheads, and synchronization correctness on actual Linux hardware."
             ])

    # =========================================================================
    # SLIDE 3: Expected Outcome & Objectives
    # =========================================================================
    s3 = prs.slides.add_slide(blank_layout)
    set_slide_background(s3)
    add_header(s3, "Expected Outcome & Core Technical Objectives")

    cards_data = [
        ("Controlled Workload Generator", [
            "• Configurable CPU workers (1 to 64)",
            "• Configurable test durations (1 to 600s)",
            "• Bounded memory limits (up to 80% RAM)",
            "• Monotonic high-resolution clock timing"
        ]),
        ("Multi-Paradigm IPC & Sync", [
            "• Anonymous pipe streaming per worker",
            "• Named pipe (FIFO) rendezvous in /tmp",
            "• POSIX Shared Memory (/dev/shm)",
            "• Mutex, CondVar, and Semaphore sync"
        ]),
        ("Virtual Memory Experiments", [
            "• Sequential vs Random memory access",
            "• Read-only vs Write-only access passes",
            "• Demand Paging verification",
            "• Copy-On-Write (COW) page duplication"
        ]),
        ("Low-Level Reporting Engine", [
            "• Direct POSIX open/write/close syscalls",
            "• Time-series CSV dataset output",
            "• Human-readable summary with CO checks",
            "• Historical performance ledger"
        ])
    ]

    for i, (title, lines) in enumerate(cards_data):
        x = Inches(0.8 + (i % 2) * 5.95)
        y = Inches(1.8 + (i // 2) * 2.6)
        add_card(s3, x, y, Inches(5.7), Inches(2.4), title, lines)

    # =========================================================================
    # SLIDE 4: Proposed Solution & Major Features
    # =========================================================================
    s4 = prs.slides.add_slide(blank_layout)
    set_slide_background(s4)
    add_header(s4, "Proposed Solution & Application Features")

    feat_cols = [
        ("Workload Modes", [
            "• CPU-Only (Process based)",
            "• Memory-Only (Virtual memory)",
            "• Combined (CPU + RAM stress)",
            "• Pthreads (Multithreaded)",
            "• Race Condition Demo (CO6)",
            "• Copy-On-Write Demo (CO4)"
        ]),
        ("Systems Programming", [
            "• fork() & execv() worker binaries",
            "• waitpid() non-blocking reaping",
            "• POSIX Shared Memory & Pipes",
            "• sigaction() graceful shutdown",
            "• Low-level syscall logging",
            "• Strict Ring 3 user execution"
        ]),
        ("Telemetry & Safety", [
            "• Live ANSI terminal dashboard",
            "• CPU % (User, System, Idle)",
            "• Minor & Major page fault counts",
            "• 80% RAM dynamic safety ceiling",
            "• Zero zombie process guarantee",
            "• Automated 20-test validation suite"
        ])
    ]

    for i, (col_title, col_lines) in enumerate(feat_cols):
        x = Inches(0.8 + i * 4.0)
        add_card(s4, x, Inches(1.8), Inches(3.7), Inches(5.0), col_title, col_lines)

    # =========================================================================
    # SLIDE 5: System Architecture Diagram
    # =========================================================================
    s5 = prs.slides.add_slide(blank_layout)
    set_slide_background(s5)
    add_header(s5, "System Architecture & High-Level Execution Pipeline")

    arch_blocks = [
        ("1. CLI & Validator", ["getopt_long parser", "Safety ceiling checks", "Dry-run simulator"], 0.8, 1.8, 3.6, 2.3),
        ("2. Workload Engines", ["Process Manager (fork)", "Thread Manager (pthreads)", "External execv (worker)"], 4.8, 1.8, 3.7, 2.3),
        ("3. IPC & Sync Layer", ["Anonymous Pipes", "Named Pipes (FIFO)", "POSIX Shared Memory", "Mutex & Semaphores"], 8.9, 1.8, 3.6, 2.3),
        ("4. Execution Kernels", ["Matrix mult (ALU/Cache)", "Hash mixing (Integer)", "Sqrt/Trans (FPU/SIMD)", "Page touch (Sequential/Rand)"], 0.8, 4.4, 3.6, 2.4),
        ("5. Kernel Monitor", ["/proc/stat CPU jiffies", "/proc/meminfo RAM stats", "/proc/self/status RSS", "getrusage() page faults"], 4.8, 4.4, 3.7, 2.4),
        ("6. File System & Reports", ["Low-level open/write/close", "Raw timestamped log", "Time-series CSV dataset", "Historical test ledger"], 8.9, 4.4, 3.6, 2.4)
    ]

    for title, lines, x, y, w, h in arch_blocks:
        add_card(s5, Inches(x), Inches(y), Inches(w), Inches(h), title, lines)

    # =========================================================================
    # SLIDE 6: Technology Stack & Systems Programming APIs
    # =========================================================================
    s6 = prs.slides.add_slide(blank_layout)
    set_slide_background(s6)
    add_header(s6, "Technology Stack & Core POSIX System Calls")

    tech_table_data = [
        ("Process Control", "fork(), execv(), waitpid(), exit(), _exit()", "Process cloning, binary image replacement, child reaping, exit codes"),
        ("Inter-Process Comm", "pipe(), mkfifo(), shm_open(), mmap(), kill()", "Kernel ring buffers, FIFO inodes, POSIX shared memory, software interrupts"),
        ("Virtual Memory", "malloc(), mmap(), munmap(), sysconf(_SC_PAGESIZE)", "Page frame allocation, demand paging, memory touching, TLB access"),
        ("Multithreading", "pthread_create(), pthread_join(), pthread_mutex_*", "Shared memory concurrency, mutual exclusion, condition variable barriers"),
        ("Synchronization", "pthread_cond_*, sem_init(), sem_wait(), sem_post()", "Thread rendezvous broadcast, counting semaphore concurrency throttling"),
        ("Low-Level File I/O", "open(), read(), write(), lseek(), close(), mkdir()", "Direct VFS interaction, inode creation, file descriptor manipulation"),
        ("System Monitoring", "/proc/stat, /proc/meminfo, /proc/self/status, getrusage()", "Kernel jiffy CPU utilization, physical memory usage, minor/major page faults")
    ]

    # Create table
    rows = len(tech_table_data) + 1
    table_shape = s6.shapes.add_table(rows, 3, Inches(0.8), Inches(1.8), Inches(11.7), Inches(4.8))
    table = table_shape.table
    table.columns[0].width = Inches(2.2)
    table.columns[1].width = Inches(4.5)
    table.columns[2].width = Inches(5.0)

    headers = ["Subsystem", "POSIX / Linux System Calls", "Underlying Operating System Mechanics"]
    for col_idx, h_text in enumerate(headers):
        cell = table.cell(0, col_idx)
        cell.fill.solid()
        cell.fill.fore_color.rgb = COLOR_CARD_BORDER
        p = cell.text_frame.paragraphs[0]
        p.text = h_text
        p.font.name = 'Segoe UI'
        p.font.size = Pt(12)
        p.font.bold = True
        p.font.color.rgb = COLOR_ACCENT_CYAN

    for row_idx, (sub, apis, mech) in enumerate(tech_table_data, start=1):
        c0, c1, c2 = table.cell(row_idx, 0), table.cell(row_idx, 1), table.cell(row_idx, 2)
        for c in (c0, c1, c2):
            c.fill.solid()
            c.fill.fore_color.rgb = COLOR_CARD_BG
        c0.text_frame.paragraphs[0].text = sub
        c0.text_frame.paragraphs[0].font.bold = True
        c0.text_frame.paragraphs[0].font.color.rgb = COLOR_TEXT_WHITE
        c0.text_frame.paragraphs[0].font.size = Pt(11)

        c1.text_frame.paragraphs[0].text = apis
        c1.text_frame.paragraphs[0].font.color.rgb = COLOR_ACCENT_BLUE
        c1.text_frame.paragraphs[0].font.size = Pt(10)

        c2.text_frame.paragraphs[0].text = mech
        c2.text_frame.paragraphs[0].font.color.rgb = COLOR_TEXT_LIGHT
        c2.text_frame.paragraphs[0].font.size = Pt(10)

    # =========================================================================
    # SLIDE 7: Course Outcomes Implementation: CO1 to CO3
    # =========================================================================
    s7 = prs.slides.add_slide(blank_layout)
    set_slide_background(s7)
    add_header(s7, "Course Outcomes Implementation: CO1, CO2, & CO3")

    co_1_3 = [
        ("CO1: OS Interface & Syscalls", [
            "• Terminal Interface: Implemented with getopt_long() parsing short/long options.",
            "• Ring 3 vs Ring 0: User mode workload loops trap into kernel mode via syscalls.",
            "• External Workers: Launches external worker executable './stress_worker' via execv().",
            "• Dry-Run Mode: Simulates memory allocation and verifies safety without execution.",
            "• Verification: ./stress_tool --dry-run and ./stress_tool -e exec"
        ]),
        ("CO2: Process Management & CPU Stress", [
            "• Process Spawning: fork() creates independent worker processes with isolated PCBs.",
            "• Workload Kernels: Matrix multiplication, integer hash mixing, and transcendentals.",
            "• Monotonic Timing: clock_gettime(CLOCK_MONOTONIC) prevents NTP clock skews.",
            "• Child Reaping: waitpid() loop prevents zombies; parses WIFEXITED & WEXITSTATUS.",
            "• Verification: ./stress_tool -m cpu -w 4 -t 10"
        ]),
        ("CO3: Inter-Process Communication", [
            "• Anonymous Pipes: pipe() transmits worker_report_t telemetry back to parent.",
            "• Named Pipes (FIFOs): mkfifo() in /tmp creates filesystem-backed rendezvous.",
            "• POSIX Shared Memory: shm_open() + mmap() in /dev/shm enables zero-copy metrics.",
            "• Signals: sigaction() traps SIGINT/SIGTERM, sends killpg(), and unlinks resources.",
            "• Verification: ./stress_tool -i pipe | -i fifo | -i shm"
        ])
    ]

    for i, (title, lines) in enumerate(co_1_3):
        x = Inches(0.8 + i * 4.0)
        add_card(s7, x, Inches(1.8), Inches(3.7), Inches(5.0), title, lines)

    # =========================================================================
    # SLIDE 8: Course Outcomes Implementation: CO4 to CO6
    # =========================================================================
    s8 = prs.slides.add_slide(blank_layout)
    set_slide_background(s8)
    add_header(s8, "Course Outcomes Implementation: CO4, CO5, & CO6")

    co_4_6 = [
        ("CO4: Virtual Memory & Paging", [
            "• Bounded Allocation: malloc() or direct mmap(MAP_ANONYMOUS | MAP_PRIVATE).",
            "• Access Patterns: Sequential (stride 4KB) vs Random page indexing (TLB misses).",
            "• Demand Paging: mmap allocation incurs 0 page faults until pages are touched.",
            "• Copy-On-Write (COW): fork() shares pages; child write triggers COW duplication.",
            "• Verification: ./stress_tool -m cow-demo -b 64"
        ]),
        ("CO5: File-System Operations", [
            "• Low-Level Syscalls: Exclusively uses open(), write(), lseek(), and close().",
            "• Structured Artifacts: Generates execution log, time-series CSV, and text summaries.",
            "• Test History Ledger: Appends runs to test_history.csv for fair comparisons.",
            "• OS Concepts: Exercises inodes, dentries, File Descriptor Table, and VFS layer.",
            "• Verification: Inspect results/ folder after any test run."
        ]),
        ("CO6: Threads & Synchronization", [
            "• POSIX Pthreads: Spawns worker threads sharing heap, joined via pthread_join().",
            "• Mutex Protection: pthread_mutex_t enforces mutual exclusion on shared counters.",
            "• Condition Variables: pthread_cond_broadcast() emits barrier launch to all threads.",
            "• Counting Semaphores: sem_t throttles concurrent computation units.",
            "• Verification: ./stress_tool -m race-demo -w 4 [--no-sync]"
        ])
    ]

    for i, (title, lines) in enumerate(co_4_6):
        x = Inches(0.8 + i * 4.0)
        add_card(s8, x, Inches(1.8), Inches(3.7), Inches(5.0), title, lines)

    # =========================================================================
    # SLIDE 9: CPU Stress-Testing Methodology
    # =========================================================================
    s9 = prs.slides.add_slide(blank_layout)
    set_slide_background(s9)
    add_header(s9, "CPU Stress-Testing Methodology & Mathematical Kernels")

    kernels = [
        ("Matrix Multiplication Kernel", [
            "• Target Units: Floating-Point ALU & L1/L2 Cache Hierarchy.",
            "• Algorithm: 32x32 double-precision floating-point matrix multiplication with O(N³) complexity.",
            "• Memory Behavior: Row-column stride stresses memory cache lines.",
            "• Instruction Mix: High proportion of fused multiply-add (FMA) instructions."
        ]),
        ("Cryptographic Hash Mixing Kernel", [
            "• Target Units: Integer Execution Pipelines & Bit-Manipulation Units.",
            "• Algorithm: 64-bit non-linear bit-mixing iterations (XORs, 64-bit rotations, prime multiplications).",
            "• Behavior: Zero memory indirection; maximizes instruction pipeline saturation.",
            "• Context: Simulates cryptographic and hashing server loads."
        ]),
        ("Transcendental Math Kernel", [
            "• Target Units: Vector SIMD Units & Hardware Square-Root Engines.",
            "• Algorithm: Interleaved sqrt(), sin(), and cos() trigonometric evaluations.",
            "• Behavior: High-latency mathematical function calls stressing hardware math coprocessors.",
            "• Context: Simulates scientific computing and physics simulation workloads."
        ])
    ]

    for i, (title, lines) in enumerate(kernels):
        y = Inches(1.8 + i * 1.7)
        add_card(s9, Inches(0.8), y, Inches(11.7), Inches(1.5), title, lines)

    # =========================================================================
    # SLIDE 10: Memory Stress-Testing Methodology
    # =========================================================================
    s10 = prs.slides.add_slide(blank_layout)
    set_slide_background(s10)
    add_header(s10, "Memory Stress-Testing Methodology & Virtual Memory")

    add_card(s10, Inches(0.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Memory Access Patterns & Hardware Effects", [
                 "• Sequential Access Pattern:",
                 "  - Iterates in strides of 4,096 bytes (sysconf(_SC_PAGESIZE)).",
                 "  - Triggers CPU hardware stream prefetchers, maximizing L3 throughput.",
                 "  - Low TLB miss penalty (~2,258 memory passes/sec).",
                 "",
                 "• Random Access Pattern:",
                 "  - Randomly touches page offsets across the entire allocation.",
                 "  - Defeats CPU prefetchers; causes frequent TLB cache misses.",
                 "  - Demonstrates ~14.2% lower throughput (~1,938 passes/sec) due to memory latency.",
                 "",
                 "• Read vs. Write Operations:",
                 "  - Controlled via --operation rw | write | read to distinguish dirty page overhead from read-only frame sharing."
             ])

    add_card(s10, Inches(6.8), Inches(1.8), Inches(5.7), Inches(5.0),
             "Copy-On-Write (COW) Experiment Walkthrough", [
                 "• Step 1: Virtual Mapping",
                 "  - mmap(64 MB, MAP_ANONYMOUS | MAP_PRIVATE).",
                 "  - Minor page faults = 0. Physical RAM is NOT committed.",
                 "  - Concept: Demand Paging (lazy allocation).",
                 "",
                 "• Step 2: Page Touching",
                 "  - Writing 1 byte to all 16,384 pages.",
                 "  - Observed Minor Faults = exactly 16,384 (+100%).",
                 "  - Concept: Hardware MMU exception maps physical frames.",
                 "",
                 "• Step 3: Copy-On-Write via fork()",
                 "  - Child process read pass = 0 page faults (shared frames).",
                 "  - Child write pass to 8,192 pages = exactly 8,192 minor faults.",
                 "  - Concept: Kernel duplicates only modified frames."
             ])

    # =========================================================================
    # SLIDE 11: Performance Monitoring & Low-Level Reports
    # =========================================================================
    s11 = prs.slides.add_slide(blank_layout)
    set_slide_background(s11)
    add_header(s11, "Real-Time Monitoring & Low-Level Syscall Reports")

    mon_items = [
        ("Linux /proc Subsystem Parsers", [
            "• /proc/stat: Parsed for user, nice, system, idle, and iowait jiffies. Computes exact system-wide CPU percentage deltas.",
            "• /proc/meminfo: Parsed for MemTotal, MemFree, and MemAvailable to verify memory safety.",
            "• /proc/self/status & getrusage(): Parsed for process VmRSS, VmSize, and minor/major page faults."
        ]),
        ("Live ANSI Terminal Dashboard", [
            "• Emits single-line status updates every sampling interval (e.g., 1000 ms).",
            "• Displays: [ELAPSED] [CPU% (User/Sys)] [SYS MEM] [APP RSS] [PAGE FAULTS] [THROUGHPUT].",
            "• Guarantees zero GUI dependencies; runs on headless Linux servers and SSH terminals."
        ]),
        ("Four Generated Persistent Artifacts (CO5)", [
            "1. Raw Syscall Log (stress_*.log): Timestamped trace of worker initialization, execution, and exit codes.",
            "2. Time-Series CSV (stress_*.csv): Granular resource metrics per second for spreadsheet and graph plotting.",
            "3. Human-Readable Summary (stress_*_summary.txt): Complete test recap with CO verification checkpoints.",
            "4. Historical Ledger (test_history.csv): Single-line cumulative summary appending runs for fair benchmarking."
        ])
    ]

    for i, (title, lines) in enumerate(mon_items):
        y = Inches(1.8 + i * 1.7)
        add_card(s11, Inches(0.8), y, Inches(11.7), Inches(1.5), title, lines)

    # =========================================================================
    # SLIDE 12: Testing Strategy & Automated Validation Scenarios
    # =========================================================================
    s12 = prs.slides.add_slide(blank_layout)
    set_slide_background(s12)
    add_header(s12, "Verification Strategy & Automated Test Suite")

    test_suites = [
        ("test_config.sh (CO1)", [
            "• Version and help banners",
            "• Dry-run safety simulation",
            "• Invalid mode rejection",
            "• Excessive worker rejection",
            "• Negative duration rejection",
            "• Over-memory safety ceiling",
            "Status: [PASS] 7/7 Subtests"
        ]),
        ("test_cpu.sh (CO2)", [
            "• Single-worker execution",
            "• 4-worker CPU scaling",
            "• Hash & Sqrt algorithms",
            "• execv() external worker",
            "• Monotonic duration check",
            "• Zombie reaping verification",
            "Status: [PASS] 4/4 Subtests"
        ]),
        ("test_memory.sh (CO4)", [
            "• Sequential malloc pass",
            "• Random mmap pass",
            "• Read-only access mode",
            "• Page fault telemetry",
            "• Demand paging test",
            "• Copy-On-Write demo",
            "Status: [PASS] 4/4 Subtests"
        ]),
        ("test_ipc.sh (CO3)", [
            "• Anonymous pipe IPC",
            "• Named pipe (FIFO) in /tmp",
            "• POSIX Shared Memory",
            "• SIGINT graceful stop",
            "• Signal child broadcast",
            "• Resource unlink cleanup",
            "Status: [PASS] 4/4 Subtests"
        ]),
        ("test_threads.sh (CO6)", [
            "• POSIX pthreads execution",
            "• Condition variable barrier",
            "• Semaphore task throttle",
            "• Unsync race condition demo",
            "• Mutex-synchronized demo",
            "• Correctness verification",
            "Status: [PASS] 3/3 Subtests"
        ]),
        ("test_reports.sh (CO5)", [
            "• Low-level open/write/close",
            "• CSV header & data validity",
            "• Text summary generation",
            "• Course outcome checkpoints",
            "• Historical ledger append",
            "• File permission handling",
            "Status: [PASS] 4/4 Subtests"
        ])
    ]

    for i, (title, lines) in enumerate(test_suites):
        x = Inches(0.8 + (i % 3) * 4.0)
        y = Inches(1.8 + (i // 3) * 2.6)
        border = COLOR_GREEN_PASS if "PASS" in lines[-1] else COLOR_CARD_BORDER
        add_card(s12, x, y, Inches(3.7), Inches(2.4), title, lines, border_color=border)

    # =========================================================================
    # SLIDE 13: Actual Results & Performance Comparison
    # =========================================================================
    s13 = prs.slides.add_slide(blank_layout)
    set_slide_background(s13)
    add_header(s13, "Empirical Benchmark Results & System Performance")

    results_data = [
        ("CPU (1 Worker)", "1 Proc", "3.0s", "N/A", "12.5%", "2 MB", "97", "73,856", "24,618 it/s", "COMPLETED"),
        ("CPU (2 Workers)", "2 Procs", "3.0s", "N/A", "25.1%", "2 MB", "98", "147,328", "48,755 it/s", "COMPLETED"),
        ("CPU (4 Workers)", "4 Procs", "3.0s", "N/A", "50.2%", "2 MB", "102", "291,456", "96,829 it/s", "COMPLETED"),
        ("CPU (execv Worker)", "2 Procs", "3.0s", "N/A", "25.0%", "2 MB", "102", "152,064", "50,330 it/s", "COMPLETED"),
        ("Memory (Sequential)", "2 Procs", "3.0s", "128 MB", "24.8%", "2 MB", "32,866", "6,880 passes", "2,258 it/s", "COMPLETED"),
        ("Memory (Random)", "2 Procs", "3.0s", "128 MB", "24.9%", "2 MB", "32,866", "5,912 passes", "1,938 it/s", "COMPLETED"),
        ("Pthreads Workload", "4 Threads", "3.0s", "N/A", "49.9%", "2 MB", "103", "143,104", "47,298 it/s", "COMPLETED"),
        ("Race Demo (Unsync)", "4 Threads", "0.002s", "N/A", "N/A", "2 MB", "92", "608,212 / 2.0M", "69.6% Data Loss", "RACE HAZARD"),
        ("Race Demo (Mutex)", "4 Threads", "0.107s", "N/A", "N/A", "2 MB", "92", "2,000,000 / 2.0M", "100% Match", "CORRECT")
    ]

    t_shape = s13.shapes.add_table(len(results_data) + 1, 10, Inches(0.8), Inches(1.8), Inches(11.7), Inches(5.0))
    table = t_shape.table
    col_widths = [Inches(1.8), Inches(1.1), Inches(0.8), Inches(1.0), Inches(1.0), Inches(1.0), Inches(1.0), Inches(1.6), Inches(1.2), Inches(1.2)]
    for idx, w in enumerate(col_widths):
        table.columns[idx].width = w

    headers = ["Test Mode", "Workers", "Duration", "Memory", "CPU %", "RSS", "Page Flts", "Iterations", "Throughput", "Status"]
    for col_idx, h_text in enumerate(headers):
        cell = table.cell(0, col_idx)
        cell.fill.solid()
        cell.fill.fore_color.rgb = COLOR_CARD_BORDER
        p = cell.text_frame.paragraphs[0]
        p.text = h_text
        p.font.name = 'Segoe UI'
        p.font.size = Pt(10)
        p.font.bold = True
        p.font.color.rgb = COLOR_ACCENT_CYAN

    for row_idx, row_data in enumerate(results_data, start=1):
        for col_idx, val in enumerate(row_data):
            cell = table.cell(row_idx, col_idx)
            cell.fill.solid()
            cell.fill.fore_color.rgb = COLOR_CARD_BG
            p = cell.text_frame.paragraphs[0]
            p.text = val
            p.font.name = 'Segoe UI'
            p.font.size = Pt(9)
            if col_idx == 0:
                p.font.bold = True
                p.font.color.rgb = COLOR_TEXT_WHITE
            elif col_idx == 9:
                p.font.bold = True
                p.font.color.rgb = COLOR_GREEN_PASS if "COMPLETED" in val or "CORRECT" in val else COLOR_RED_ALERT
            else:
                p.font.color.rgb = COLOR_TEXT_LIGHT

    # =========================================================================
    # SLIDE 14: Safety Controls, Resource Limits & Future Scope
    # =========================================================================
    s14 = prs.slides.add_slide(blank_layout)
    set_slide_background(s14)
    add_header(s14, "Safety Boundaries, Resource Limits & Future Work")

    add_card(s14, Inches(0.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Built-In Operating System Safeguards", [
                 "• Dynamic RAM Safety Ceiling:",
                 "  - Reads /proc/meminfo at startup.",
                 "  - Rejects any allocation exceeding 80% available RAM.",
                 "  - Prevents system freezing and OOM killer invocations.",
                 "",
                 "• Process & Duration Bounding:",
                 "  - Workers constrained to 1 <= W <= 64.",
                 "  - Test duration capped at 600s max default.",
                 "",
                 "• Clean Signal Trapping & Reaping:",
                 "  - Catches SIGINT and SIGTERM gracefully.",
                 "  - Immediately signals worker process group and reaps via waitpid().",
                 "  - Unlinks all shared memory and FIFO files in /tmp and /dev/shm."
             ])

    add_card(s14, Inches(6.8), Inches(1.8), Inches(5.7), Inches(5.0),
             "Architectural Limitations & Future Scope", [
                 "• Existing System Boundaries:",
                 "  - Focuses on CPU, memory, and local file I/O subsystems; network stress testing (sockets) not currently included.",
                 "  - Linux specific interfaces (/proc, POSIX SHM) require POSIX abstraction layer on non-Linux OS.",
                 "",
                 "• Planned Future Enhancements:",
                 "  - NUMA (Non-Uniform Memory Access) node locality tuning via libnuma.",
                 "  - Linux Control Groups (cgroups v2) integration to enforce hard CPU shares and memory throttles.",
                 "  - Real-Time Scheduling policies (SCHED_FIFO and SCHED_RR) evaluation.",
                 "  - Direct disk block I/O stress using O_DIRECT flags."
             ])

    # =========================================================================
    # SLIDE 15: Conclusion & Live Demonstration Sequence
    # =========================================================================
    s15 = prs.slides.add_slide(blank_layout)
    set_slide_background(s15)
    add_header(s15, "Conclusion & Live Demonstration Sequence")

    add_card(s15, Inches(0.8), Inches(1.8), Inches(5.6), Inches(5.0),
             "Project Summary & Key Takeaways", [
                 "• Complete Course Outcomes Fulfillment: Demonstrated all 6 OSSP outcomes (CO1 to CO6) in a cohesive, working C application.",
                 "• Systems-First Engineering: Implemented direct kernel interfaces, bypassing high-level wrappers for low-level syscalls.",
                 "• Real Empirical Insights: Proved demand paging behaviors, Copy-On-Write duplication, and empirical race conditions.",
                 "• 100% Automated Test Pass Rate: 20 regression test cases validated under GNU Make across all modules.",
                 "• Clean Git-Ready Deliverable: Includes complete source, headers, Makefile, tests, reports, and presentation."
             ])

    add_card(s15, Inches(6.8), Inches(1.8), Inches(5.7), Inches(5.0),
             "Recommended Live Demonstration Sequence", [
                 "1. Safety & Dry-Run (CO1):",
                 "   ./stress_tool -m combined -w 4 -b 256 --dry-run",
                 "2. CPU Scaling & waitpid Reaping (CO2):",
                 "   ./stress_tool -m cpu -w 4 -t 5 -a matrix",
                 "3. External execv() Worker Execution (CO1/CO2):",
                 "   ./stress_tool -m cpu -w 2 -t 3 -e exec -i pipe",
                 "4. Demand Paging & Copy-On-Write Demo (CO4):",
                 "   ./stress_tool -m cow-demo -b 64",
                 "5. Thread Race Demo vs Mutex Correctness (CO6):",
                 "   ./stress_tool -m race-demo -w 4 --no-sync",
                 "   ./stress_tool -m race-demo -w 4",
                 "6. Low-Level Reports & CSV Inspection (CO5):",
                 "   cat results/test_history.csv"
             ])

    # Output PowerPoint file
    out_dir = "cpu-memory-stress-testing-tool/presentation"
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "CPU_Memory_Stress_Testing_Tool.pptx")
    prs.save(out_path)
    print(f"[SUCCESS] Generated 15-slide presentation at: {out_path}")

if __name__ == '__main__':
    create_presentation()
